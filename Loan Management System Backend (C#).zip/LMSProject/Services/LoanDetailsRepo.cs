﻿using LMSProject.Models;

namespace LMSProject.Services
{
    /* public class LoanDetailsRepo : IRepo<int, LoanDetails>*/
    public class LoanDetailsRepo : ILoan<int, LoanDetails>
    {

        private readonly LmsContext _context;

        public LoanDetailsRepo(LmsContext context)
        {
            _context = context;
        }
        public LoanDetails Add(LoanDetails item)
        {
            /*try
            {
                _context.Add(item);
                _context.SaveChanges();
                return item;
            }*/
            try
            {
                var loans = _context.UserDetails.SingleOrDefault(x => x.UserName == item.UserName);
                if (loans != null)
                {
                    _context.Add(item);
                    _context.SaveChanges();
                    return item;
                }
                return null;
            }
            catch (Exception e)
            {

            }
            return null;
        }

        public LoanDetails Delete(int key)
        {
            var emp = Get(key);
            if (emp != null)
            {
                try
                {
                    _context.LoanDetails.Remove(emp);
                    _context.SaveChanges();
                    return emp;
                }
                catch (Exception e)
                {

                    throw;
                }
            }
            return null;

        }

        public LoanDetails Get(int key)
        {
            var emp = _context.LoanDetails.FirstOrDefault(e => e.LoanId == key);
            if (emp != null)
            {
                try
                {
                    return emp;
                }
                catch (Exception e)
                {
                }
            }
            return null;
        }

        public ICollection<LoanDetails> GetAll()
        {
            var employees = _context.LoanDetails.ToList();
            return employees;
        }

        public LoanDetails Update(LoanDetails item)
        {

            var emp = Get(item.LoanId);
            if (emp != null)
            {
                try
                {
                    emp.Amount = item.Amount;
                    emp.currentdate = item.currentdate;
                    emp.LoanType = item.LoanType;
                  
                  /* emp.LoanStatus = item.LoanStatus;*/

                    _context.SaveChanges();
                    return emp;
                }
                catch (Exception e)
                {

                    throw;
                }
            }
            return null;
        }

        /* public LoanDetails UpdateStatus(LoanDetails item)
         {
             var user = Get(item.LoanId);
             if (user != null)
             {
                 try
                 {
                     user.LoanStatus = item.LoanStatus;
                     _context.SaveChanges();
                     return user;
                 }
                 catch (Exception e)
                 {

                     throw;
                 }
             }
             return null;
         }*/
        public LoanDetails UpdateStatus(ULoanStatusDTO item)
        {
            var user = Get(item.Id);
            if (user != null)
            {
                try
                {
                    user.LoanStatus = item.Status;
                    _context.SaveChanges();
                    return user;
                }
                catch (Exception e)
                {

                    throw;
                }
            }
            return null;
        }
    }
}
