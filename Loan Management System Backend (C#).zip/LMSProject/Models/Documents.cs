﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace LMSProject.Models
{
    public class Documents
    {
        [Key]
        public string UserName { get; set; }
        public long AadharNo { get; set; }
        public string PanNo { get; set; }
        public string DL_No { get; set; }

        [ForeignKey("UserName")]
        public Login? login { get; set; }
    }
}
