﻿namespace LMSProject.Models
{
    public class UserPassDTO : Login
    {
        public string? Password { get; set; }
    }
}
