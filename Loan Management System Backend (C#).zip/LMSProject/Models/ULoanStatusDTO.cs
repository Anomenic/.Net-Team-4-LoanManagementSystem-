﻿namespace LMSProject.Models
{
    public class ULoanStatusDTO
    {
        public int Id { get; set; }
        public string Status { get; set; }
    }
}
